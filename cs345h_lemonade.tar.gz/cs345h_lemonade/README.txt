Lemonade Programming Language Interpreter and Shell

Steven Chen (zc3428)
Samantha Miller (sam5799)
Stephen Ngo (sen494)
Kevin Tai (krt752)
Virin Tamprateep (vt4624)


To compile the interpreter:

make
./l-interpreter example.lemon

To compile the REPL shell:

make repl
./l-repl

To exit REPL, ^C


